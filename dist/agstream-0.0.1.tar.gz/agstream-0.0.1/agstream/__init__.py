# -*- coding: utf-8 -*-

"""
    Agstream Module
    ---------------
    Necessary stuff to connect and to use data from the Agriscope server
"""

__version__ = "0.0.1"


from session import AgspSession
from devices import Agribase,Sensor